package com.koehlert.rpg.main;

public class Info {
    public static final int Height = 800;
    public static final int Width = 1200;
}
