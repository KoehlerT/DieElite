package com.koehlert.rpg.mainMenu;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.koehlert.rpg.game.GameState;
import com.koehlert.rpg.input.MouseInfo;
import com.koehlert.rpg.loadingScreen.loadingState;
import com.koehlert.rpg.main.StateEngine;
import com.koehlert.rpg.utillity.Observable;
import com.koehlert.rpg.utillity.Observer;
import com.koehlert.rpg.utillity.State;

public class MenuScreen implements State, Observer {

    Texture background;

    @Override
    public void Show() {
        background = new Texture("menuback.png");
        MouseInfo.getInstance().addObserver(this);
    }

    @Override
    public void Render(SpriteBatch batch) {
        batch.draw(background,0,0);
    }

    @Override
    public void Update(float delta) {

    }

    @Override
    public void dispose() {
        background.dispose();
        MouseInfo.getInstance().deleteObserver(this);
    }

    @Override
    public void Update(Observable observable, Object sender) {
        //Es wurde geklickt
        //State newState = new GameState();
        State newState = new loadingState();
        this.dispose();
        StateEngine.getInstance().SwitchState(newState);
    }
}
