package com.koehlert.rpg.game.rooms;

import com.koehlert.rpg.game.interactables.Interactable;
import com.koehlert.rpg.game.interactables.Traber;

public class Classroom1 extends Room {
    public Classroom1() {
        super("klassenraumback.png");
        Interactable traber = new Traber();
        setInteractables(new Interactable[]{traber});
    }
}
