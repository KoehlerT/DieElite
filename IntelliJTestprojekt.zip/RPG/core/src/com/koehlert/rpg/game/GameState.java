package com.koehlert.rpg.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.koehlert.rpg.game.dialogueEngine.DialogueController;
import com.koehlert.rpg.game.dialogueEngine.DialogueRenderer;
import com.koehlert.rpg.game.player.Player;
import com.koehlert.rpg.game.rooms.CorridorBase;
import com.koehlert.rpg.utillity.State;

public class GameState implements State {
    private RoomChanger roomChanger;
    private GameRenderer gameRenderer;
    private GameController gameController;
    private Player player;

    @Override
    public void Show() {
        player = new Player();
        roomChanger = new RoomChanger();
        gameRenderer = new GameRenderer();
        gameController = new GameController();
        roomChanger.changeRoom(new CorridorBase());
    }

    @Override
    public void Render(SpriteBatch batch) {
        gameRenderer.Render(batch);
    }

    @Override
    public void Update(float delta) {
        gameController.UpdateLogic(delta);
    }

    @Override
    public void dispose() {
        gameController.dispose();
        player.dispose();
    }
}
