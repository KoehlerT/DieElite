package com.koehlert.rpg.game;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.koehlert.rpg.game.dialogueEngine.DialogueRenderer;
import com.koehlert.rpg.game.interactables.Interactable;
import com.koehlert.rpg.game.player.Player;
import com.koehlert.rpg.game.rooms.Room;

public class GameRenderer {

    public DialogueRenderer dialogueRenderer;

    public GameRenderer(){
        dialogueRenderer = new DialogueRenderer();
    }

    public void Render(SpriteBatch batch){
        Room toRender = RoomChanger.getInstance().getCurrent();
        Player player = Player.getInstance();
        batch.draw(toRender.getBackground(),0,0);
        batch.draw(player.getTexture(),player.getX(),player.getY());

        //Interactables
        Interactable[] ints = toRender.getInteractables();
        for( Interactable i : ints) batch.draw(i.getTexture(), i.getPosition().x,i.getPosition().y);

        //Dialogues
        dialogueRenderer.draw(batch);
    }
}
