package com.koehlert.rpg.game.rooms;

import com.badlogic.gdx.math.Vector2;
import com.koehlert.rpg.game.interactables.Interactable;
import com.koehlert.rpg.game.interactables.Ranzen;

public class CorridorBase extends Room{
    public CorridorBase(){
        super("gangback.png");
        Interactable ranzen = new Ranzen(new Vector2(200,200));
        super.setInteractables(new Interactable[]{ranzen});
    }
}
