package com.koehlert.rpg.utillity;

public interface Observer {
    public void Update(Observable observable, Object sender);
}
